

export const index = 2;
export const component = async () => (await import('../entries/pages/_page.svelte.js')).default;
export const imports = ["_app/immutable/nodes/2.93c0c0d3.js","_app/immutable/chunks/index.f9843ce4.js","_app/immutable/chunks/index.7e6ce692.js","_app/immutable/chunks/control.f5b05b5f.js"];
export const stylesheets = ["_app/immutable/assets/2.63675601.css"];
export const fonts = [];
