

export const index = 1;
export const component = async () => (await import('../entries/fallbacks/error.svelte.js')).default;
export const imports = ["_app/immutable/nodes/1.67654229.js","_app/immutable/chunks/index.f9843ce4.js","_app/immutable/chunks/singletons.2a00d2da.js","_app/immutable/chunks/index.7e6ce692.js"];
export const stylesheets = [];
export const fonts = [];
