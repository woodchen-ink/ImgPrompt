

export const index = 0;
export const component = async () => (await import('../entries/fallbacks/layout.svelte.js')).default;
export const imports = ["_app/immutable/nodes/0.4004eefa.js","_app/immutable/chunks/index.f9843ce4.js"];
export const stylesheets = [];
export const fonts = [];
